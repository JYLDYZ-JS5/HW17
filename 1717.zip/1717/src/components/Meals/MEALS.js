import { Available } from "./Available";
import MealsSummary from "./MealsSummary";

 export function Meals(){
    return(
        <>
        <MealsSummary />
        <Available />
        </>
    )
}