import { useReducer } from 'react'
import { CartContext } from './cart-context'

const defaultCartState = {
  items: [],
  totalAmount: 0,
  selectedItem: [],
  filteredprice:0,
}
function cartReducer(prevState, action) {
  if (action.type === 'ADD') {

    const updatedItems = prevState.items.concat(action.item) //добавляет к

    const updatedTotalAmount = prevState.totalAmount + (action.item.price * action.item.amount)

    
    const selectedItems = prevState.selectedItem.concat(action.selectedItem)
    const selected = selectedItems.filter(
      (el, id) => selectedItems.indexOf(el) === id,
    )
    const filteredprices=prevState.filteredPrice+ action.filteredPrice * action.selectedItem.amount

    return {
      items: updatedItems,
      totalAmount: updatedTotalAmount,
      selectedItem: selected,
     
      filteredprice:filteredprices
    }
  }
  return defaultCartState
}

function CartProvider(props) {
  const [cartState, dispatchCartState] = useReducer(
    cartReducer,
    defaultCartState,
  )

  const addItemToCartHandler = (item, selected,filteredprice) => {
    dispatchCartState({ type: 'ADD', item: item, selectedItem: selected , filteredPrice:filteredprice})
  }

  function removeItemFromCartHandler(id) {}

  const cartContext = {
    items: cartState.items,
    totalAmount: cartState.totalAmount,
    addItem: addItemToCartHandler,
    removeItem: removeItemFromCartHandler,
    selectedItem: cartState.selectedItem,
    filteredprice:cartState.filteredprice
  }

  return (
    <CartContext.Provider value={cartContext}>
      {props.children}
    </CartContext.Provider>
  )
}
export default CartProvider
